﻿using CodeRace;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GoogleNews_API
{
    public partial class Registro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEnviarRegisto_Click(object sender, EventArgs e)
        {
            //Busca os parametros de conexao da config
            string conexao = ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString();

            //Abre conexão com o banco de dados
            SqlServerConnector banco = new SqlServerConnector(conexao);

            //Verifica se esta conectado com o banco de dados
            if (banco.Conectado())
            {
                banco.ClearParameters();
                banco.Query = "SELECT * FROM USUARIOS WHERE email = @email";
                banco.AddParameters("@email", DbType.String, Email.Text);
                DataTable data = banco.ExecuteReader();
                if(data.Rows.Count > 0)
                    throw new Exception("E-mail já cadastrado");
                else
                {
                    banco.ClearParameters();
                    banco.Query = "INSERT INTO USUARIOS (NOME, EMAIL, SENHA) VALUES (@nome, @email, @senha)";
                    banco.AddParameters("@email", DbType.String, Email.Text);
                    banco.AddParameters("@nome", DbType.String, string.Concat(Nome.Text, Sobrenome.Text));
                    banco.AddParameters("@senha", DbType.String, Senha.Text);
                    DataTable data2 = banco.ExecuteReader();
                }
                banco.Dispose();
            }
        }
    }

    internal class Usuarios
    {
        public string nome;
        public string email;
        public string senha;
    }
}