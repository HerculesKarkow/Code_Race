﻿function setaImagem() {
    var settings = {
        primeiraImg: function () {
            elemento = document.querySelector("#slider a:first-child");
            elemento.classList.add("ativo");
            this.legenda(elemento);
        },

        slide: function () {
            elemento = document.querySelector(".ativo");

            if (elemento.nextElementSibling) {
                elemento.nextElementSibling.classList.add("ativo");
                settings.legenda(elemento.nextElementSibling);
                elemento.classList.remove("ativo");
            } else {
                elemento.classList.remove("ativo");
                settings.primeiraImg();
            }

        },

        proximo: function () {
            clearInterval(intervalo);
            elemento = document.querySelector(".ativo");

            if (elemento.nextElementSibling) {
                elemento.nextElementSibling.classList.add("ativo");
                settings.legenda(elemento.nextElementSibling);
                elemento.classList.remove("ativo");
            } else {
                elemento.classList.remove("ativo");
                settings.primeiraImg();
            }
            intervalo = setInterval(settings.slide, 4000);
        },

        anterior: function () {
            clearInterval(intervalo);
            elemento = document.querySelector(".ativo");

            if (elemento.previousElementSibling) {
                elemento.previousElementSibling.classList.add("ativo");
                settings.legenda(elemento.previousElementSibling);
                elemento.classList.remove("ativo");
            } else {
                elemento.classList.remove("ativo");
                elemento = document.querySelector("a:last-child");
                elemento.classList.add("ativo");
                this.legenda(elemento);
            }
            intervalo = setInterval(settings.slide, 4000);
        },

        legenda: function (obj) {
            var legenda = obj.querySelector("img").getAttribute("alt");
            document.querySelector("figcaption").innerHTML = legenda;
        }

    }

    //chama o slide
    settings.primeiraImg();

    //chama a legenda
    settings.legenda(elemento);

    //chama o slide à um determinado tempo
    var intervalo = setInterval(settings.slide, 4000);
    document.querySelector(".next").addEventListener("click", settings.proximo, false);
    document.querySelector(".prev").addEventListener("click", settings.anterior, false);
}


window.addEventListener("load", setaImagem, false);


function SubmitOrEnter(searchBox, event) {
    var keyCode;
    if (window.event) {
        keyCode = window.event.keyCode;
    }
    else if (event) {
        keyCode = event.which;
    }
    else {
        return true;
    }
    if (keyCode == 13) {
        SiteSearch();
        return false;
    }
    else {
        return true;
    }
}

function SiteSearch() {
    document.location.href = "/SearchResult.aspx?q=" +
        EncodeText(document.getElementById('q').value);
    //document.getElementById('q').value;

}

function EncodeText(value) {
    var returnValue = "";
    var x = 0;
    var regex = /(^[a*zA-Z0-9_.])/;
    while (x < value.toString().length) {
        var match = regex.exec(value.substr(x));
        if (match != null && match.length > 1 && match[1] != '') {
            return value += match[1];
            x += match[1].length;
        }
        else {
            if (value[x] == ' ')
                returnValue += '+';
            else {
                var charCode = value.charCodeAt(x);
                var haxValue = charCode.toString(16);
                returnValue += "%" + (haxValue.length < 2 ? '0' : '') + haxValue.toUpperCase();
            }
            x++;
        }
    }
    return returnValue;
}